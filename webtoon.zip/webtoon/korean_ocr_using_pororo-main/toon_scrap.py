import os
import requests
from bs4 import BeautifulSoup
from PIL import Image
from io import BytesIO


base_url = "https://m.comic.naver.com/webtoon/detail?titleId=810682&no={episode_num}&week=wed&listSortOrder=ASC&listPage={page_num}"

# User-Agent 설정
headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
}

# 웹툰 이미지를 저장할 korean_ocr_pororo 폴더 내 webtoon_images 경로 설정
root_dir = os.path.dirname(os.path.abspath(__file__))  # 현재 스크립트가 있는 디렉토리의 절대 경로
save_root = os.path.join(root_dir, "webtoon_images")  # webtoon_images 폴더를 생성할 경로

# webtoon_images 폴더가 없으면 생성
if not os.path.exists(save_root):
    os.makedirs(save_root)

# 1페이지 (1화부터 30화까지)
for episode_num in range(1, 31):
    episode_url = base_url.format(episode_num=episode_num, page_num=1)
    print(f"회차 URL: {episode_url}")

    # 회차 페이지 요청
    episode_response = requests.get(episode_url, headers=headers)
    soup = BeautifulSoup(episode_response.text, "html.parser")

    # 저장할 폴더 경로 설정 (1화는 1, 2화는 2 등 회차 번호로 폴더 생성)
    save_path = os.path.join(save_root, str(episode_num))

    # 폴더 생성
    if not os.path.exists(save_path):
        os.makedirs(save_path)
        print(f"폴더 생성 완료: {save_path}")
    else:
        print(f"폴더가 이미 존재합니다: {save_path}")

    # 이미지 태그 추출
    image_tags = soup.select("div#ct img")

    for idx, img_tag in enumerate(image_tags):
        # data-src 우선 사용
        img_url = (
            img_tag.get("data-src") if img_tag.get("data-src") else img_tag.get("src")
        )

        # 투명 이미지 또는 잘못된 이미지 제외
        if "static/agerate" in img_url or "bg_transparency" in img_url:
            print(f"투명 이미지 스킵: {img_url}")
            continue

        try:
            # 이미지 요청
            img_response = requests.get(img_url, headers=headers)

            # 콘텐츠 타입 확인
            content_type = img_response.headers["Content-Type"]
            if "image" not in content_type:
                print(f"이미지 아님: {img_url}")
                continue

            # 이미지 열기
            img = Image.open(BytesIO(img_response.content))

            # 이미지 저장 경로 설정
            img_path = os.path.join(save_path, f"{idx + 1}.jpg")

            # 이미지 저장
            img.save(img_path)
            print(f"이미지 {idx + 1} 저장 완료: {img_path}")

        except Exception as e:
            print(f"이미지 {idx + 1} 저장 실패: {e}")

# 2페이지 (31화부터 43화까지 크롤링)
for episode_num in range(31, 44):
    episode_url = base_url.format(episode_num=episode_num, page_num=2)
    print(f"회차 URL: {episode_url}")

    # 회차 페이지 요청
    episode_response = requests.get(episode_url, headers=headers)
    soup = BeautifulSoup(episode_response.text, "html.parser")

    # 저장할 폴더 경로 설정 (31화는 31, 32화는 32 등 회차 번호로 폴더 생성)
    save_path = os.path.join(save_root, str(episode_num))

    # 폴더 생성
    if not os.path.exists(save_path):
        os.makedirs(save_path)
        print(f"폴더 생성 완료: {save_path}")
    else:
        print(f"폴더가 이미 존재합니다: {save_path}")

    # 이미지 태그 추출
    image_tags = soup.select("div#ct img")

    for idx, img_tag in enumerate(image_tags):
        # data-src 우선 사용
        img_url = (
            img_tag.get("data-src") if img_tag.get("data-src") else img_tag.get("src")
        )

        # 투명 이미지 또는 잘못된 이미지 제외
        if "static/agerate" in img_url or "bg_transparency" in img_url:
            print(f"투명 이미지 스킵: {img_url}")
            continue

        try:
            # 이미지 요청
            img_response = requests.get(img_url, headers=headers)

            # 콘텐츠 타입 확인
            content_type = img_response.headers["Content-Type"]
            if "image" not in content_type:
                print(f"이미지 아님: {img_url}")
                continue

            # 이미지 열기
            img = Image.open(BytesIO(img_response.content))

            # 이미지 저장 경로 설정
            img_path = os.path.join(save_path, f"{idx + 1}.jpg")

            # 이미지 저장
            img.save(img_path)
            print(f"이미지 {idx + 1} 저장 완료: {img_path}")

        except Exception as e:
            print(f"이미지 {idx + 1} 저장 실패: {e}")

print("모든 회차의 이미지 저장 완료!")

# import os
# import requests
# from bs4 import BeautifulSoup
# from PIL import Image
# from io import BytesIO

# # 웹툰 회차 링크 템플릿 (페이지 번호는 1 또는 2에 따라 변경)
# base_url = "https://m.comic.naver.com/webtoon/detail?titleId=810682&no={episode_num}&week=wed&listSortOrder=ASC&listPage={page_num}"

# # User-Agent 설정
# headers = {
#     "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
# }

# # 웹툰 이미지를 저장할 korean_ocr_pororo 폴더 내 webtoon_images 경로 설정
# root_dir = os.path.dirname(os.path.abspath(__file__))  # 현재 스크립트가 있는 디렉토리의 절대 경로
# save_root = os.path.join(root_dir, "webtoon_images")  # webtoon_images 폴더를 생성할 경로

# # webtoon_images 폴더가 없으면 생성
# if not os.path.exists(save_root):
#     os.makedirs(save_root)

# # 1페이지 (1화부터 30화까지 크롤링)
# for episode_num in range(1, 31):
#     episode_url = base_url.format(episode_num=episode_num, page_num=1)
#     print(f"회차 URL: {episode_url}")

#     # 회차 페이지 요청
#     episode_response = requests.get(episode_url, headers=headers)
#     soup = BeautifulSoup(episode_response.text, "html.parser")

#     # 회차 제목 추출 (meta 태그에서 og:title 속성 확인)
#     episode_title_tag = soup.find("meta", property="og:title")

#     if episode_title_tag:
#         episode_title = episode_title_tag["content"]
#         # 파일명에 문제될 수 있는 문자를 제거하고 폴더 이름 생성
#         episode_title_clean = (
#             episode_title.replace(" ", "_").replace(":", "_").replace("-", "_")
#         )
#         print(f"회차 제목: {episode_title}")  # 디버깅용
#     else:
#         print("회차 제목을 찾을 수 없습니다.")
#         continue

#     # 저장할 폴더 경로 설정 (webtoon_images 내부에 회차별로 폴더 생성)
#     save_path = os.path.join(save_root, episode_title_clean)

#     # 폴더 생성
#     if not os.path.exists(save_path):
#         os.makedirs(save_path)
#         print(f"폴더 생성 완료: {save_path}")
#     else:
#         print(f"폴더가 이미 존재합니다: {save_path}")

#     # 이미지 태그 추출
#     image_tags = soup.select("div#ct img")

#     for idx, img_tag in enumerate(image_tags):
#         # data-src 우선 사용
#         img_url = (
#             img_tag.get("data-src") if img_tag.get("data-src") else img_tag.get("src")
#         )

#         # 투명 이미지 또는 잘못된 이미지 제외
#         if "static/agerate" in img_url or "bg_transparency" in img_url:
#             print(f"투명 이미지 스킵: {img_url}")
#             continue

#         try:
#             # 이미지 요청
#             img_response = requests.get(img_url, headers=headers)

#             # 콘텐츠 타입 확인
#             content_type = img_response.headers["Content-Type"]
#             if "image" not in content_type:
#                 print(f"이미지 아님: {img_url}")
#                 continue

#             # 이미지 열기
#             img = Image.open(BytesIO(img_response.content))

#             # 이미지 저장 경로 설정
#             img_path = os.path.join(save_path, f"{idx + 1}.jpg")

#             # 이미지 저장
#             img.save(img_path)
#             print(f"이미지 {idx + 1} 저장 완료: {img_path}")

#         except Exception as e:
#             print(f"이미지 {idx + 1} 저장 실패: {e}")

# # 2페이지 (31화부터 43화까지 크롤링)
# for episode_num in range(31, 44):
#     episode_url = base_url.format(episode_num=episode_num, page_num=2)
#     print(f"회차 URL: {episode_url}")

#     # 회차 페이지 요청
#     episode_response = requests.get(episode_url, headers=headers)
#     soup = BeautifulSoup(episode_response.text, "html.parser")

#     # 회차 제목 추출 (meta 태그에서 og:title 속성 확인)
#     episode_title_tag = soup.find("meta", property="og:title")

#     if episode_title_tag:
#         episode_title = episode_title_tag["content"]
#         # 파일명에 문제될 수 있는 문자를 제거하고 폴더 이름 생성
#         episode_title_clean = (
#             episode_title.replace(" ", "_").replace(":", "_").replace("-", "_")
#         )
#         print(f"회차 제목: {episode_title}")  # 디버깅용
#     else:
#         print("회차 제목을 찾을 수 없습니다.")
#         continue

#     # 저장할 폴더 경로 설정 (webtoon_images 내부에 회차별로 폴더 생성)
#     save_path = os.path.join(save_root, episode_title_clean)

#     # 폴더 생성
#     if not os.path.exists(save_path):
#         os.makedirs(save_path)
#         print(f"폴더 생성 완료: {save_path}")
#     else:
#         print(f"폴더가 이미 존재합니다: {save_path}")

#     # 이미지 태그 추출
#     image_tags = soup.select("div#ct img")

#     for idx, img_tag in enumerate(image_tags):
#         # data-src 우선 사용
#         img_url = (
#             img_tag.get("data-src") if img_tag.get("data-src") else img_tag.get("src")
#         )

#         # 투명 이미지 또는 잘못된 이미지 제외
#         if "static/agerate" in img_url or "bg_transparency" in img_url:
#             print(f"투명 이미지 스킵: {img_url}")
#             continue

#         try:
#             # 이미지 요청
#             img_response = requests.get(img_url, headers=headers)

#             # 콘텐츠 타입 확인
#             content_type = img_response.headers["Content-Type"]
#             if "image" not in content_type:
#                 print(f"이미지 아님: {img_url}")
#                 continue

#             # 이미지 열기
#             img = Image.open(BytesIO(img_response.content))

#             # 이미지 저장 경로 설정
#             img_path = os.path.join(save_path, f"{idx + 1}.jpg")

#             # 이미지 저장
#             img.save(img_path)
#             print(f"이미지 {idx + 1} 저장 완료: {img_path}")

#         except Exception as e:
#             print(f"이미지 {idx + 1} 저장 실패: {e}")

# print("모든 회차의 이미지 저장 완료!")
