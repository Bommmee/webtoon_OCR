import os
import cv2
from pororo import Pororo

# Pororo OCR 모델 초기화
ocr = Pororo(task="ocr", lang="ko")

# 회차별로 저장된 이미지를 찾을 폴더 경로 설정
base_folder = "./webtoon_images"

# 결과를 저장할 파일
output_file = "ocr_results.txt"

# 결과 파일이 이미 존재하면 삭제
if os.path.exists(output_file):
    os.remove(output_file)

# 폴더 순회하며 이미지 파일 처리
for episode_folder in sorted(os.listdir(base_folder)):
    episode_path = os.path.join(base_folder, episode_folder)
    
    # 폴더 안에 이미지 파일이 있는지 확인
    if os.path.isdir(episode_path):
        print(f"Processing {episode_folder}...")

        for image_file in sorted(os.listdir(episode_path)):
            image_path = os.path.join(episode_path, image_file)

            if image_file.lower().endswith(('.png', '.jpg', '.jpeg')):
                print(f"Processing image: {image_path}")

                # OpenCV로 이미지 읽기 테스트
                img = cv2.imread(image_path)
                if img is None:
                    print(f"Failed to load image: {image_path}")
                    continue  # 이미지가 읽히지 않으면 건너뜁니다.

                # OCR 처리
                print(f"Running OCR on {image_file}")
                text = ocr(image_path)

                # OCR 결과 저장
                with open(output_file, 'a', encoding='utf-8') as f:
                    f.write(f"Episode: {episode_folder}, Image: {image_file}\n")
                    f.write(f"OCR Result: {text}\n\n")

print("OCR processing completed.")
