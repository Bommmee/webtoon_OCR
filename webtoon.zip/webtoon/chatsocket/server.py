# server.py
from flask import Flask, render_template
from flask_socketio import SocketIO

app = Flask(__name__)
socketio = SocketIO(app, cors_allowed_origins="*")  # 모든 출처 허용

@app.route('/')
def index():
    return "SocketIO Server Running"

@socketio.on('message')
def handle_message(message):
    print(f"Message: {message}")
    socketio.send(message, broadcast=True)  # 모든 클라이언트에게 메시지 전송

if __name__ == '__main__':
    socketio.run(app, host='0.0.0.0', port=5000)
