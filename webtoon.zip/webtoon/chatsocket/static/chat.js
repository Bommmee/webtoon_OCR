var socket = io.connect('http://localhost:5000');

socket.on('connect', function() {
    console.log('Connected to server');
});

socket.on('message', function(msg) {
    let chatBox = document.getElementById('chat-box');
    let messageElement = document.createElement('div');
    messageElement.innerText = msg;
    chatBox.appendChild(messageElement);
});

function sendMessage() {
    let messageInput = document.getElementById('message');
    let message = messageInput.value;
    socket.send(message);
    messageInput.value = '';
}
