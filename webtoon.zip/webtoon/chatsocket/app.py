from flask import Flask, render_template, request, jsonify
from flask_socketio import SocketIO, send
import random
import os

app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret!'
socketio = SocketIO(app, cors_allowed_origins="*")

# 사용자 이름과 색상을 저장할 딕셔너리
users = {}
colors = ['#FF5733', '#3498DB', '#2ECC71', '#8E44AD', '#E74C3C']

# static/lyrics 폴더 경로
LYRICS_FOLDER = 'static/lyrics'

@app.route('/')
def index():
    return render_template('chat.html')

@app.route('/lyrics/<song_title>')
def get_lyrics(song_title):
    try:
        # 곡 제목에 해당하는 텍스트 파일을 읽음
        with open(os.path.join(LYRICS_FOLDER, f"{song_title}.txt"), "r", encoding="utf-8") as file:
            lyrics = file.read()
        return jsonify({"lyrics": lyrics})
    except FileNotFoundError:
        return jsonify({"lyrics": "가사를 찾을 수 없습니다."})

@socketio.on('connect')
def handle_connect():
    sid = request.sid  # request로부터 sid 가져오기
    user_name = chr(65 + len(users))  # A, B, C, ... 순차적으로 부여
    user_color = random.choice(colors)
    users[sid] = {'name': user_name, 'color': user_color}
    print(f"User {user_name} connected with SID: {sid}")

@socketio.on('disconnect')
def handle_disconnect():
    sid = request.sid
    if sid in users:
        print(f"User {users[sid]['name']} disconnected")
        del users[sid]

@socketio.on('message')
def handleMessage(msg):
    sid = request.sid
    user_info = users.get(sid, {'name': 'Unknown', 'color': '#000000'})
    print(f"{user_info['name']} ({user_info['color']}): {msg}")
    formatted_message = f"<span style='color:{user_info['color']}'>{user_info['name']}: {msg}</span>"
    send(formatted_message, broadcast=True)

if __name__ == '__main__':
    socketio.run(app, debug=True)

# from flask import Flask, render_template, request, jsonify
# from flask_socketio import SocketIO, send
# import random
# import os

# app = Flask(__name__)
# app.config['SECRET_KEY'] = 'secret!'
# socketio = SocketIO(app, cors_allowed_origins="*")

# # 사용자 이름과 색상을 저장할 딕셔너리
# users = {}
# colors = ['#FF5733', '#3498DB', '#2ECC71', '#8E44AD', '#E74C3C']

# # static/lyrics 폴더 경로
# LYRICS_FOLDER = 'static/lyrics'

# @app.route('/')
# def index():
#     return render_template('chat.html')

# @app.route('/lyrics/<song_title>')
# def get_lyrics(song_title):
#     try:
#         # 곡 제목에 해당하는 텍스트 파일을 읽음
#         with open(os.path.join(LYRICS_FOLDER, f"{song_title}.txt"), "r", encoding="utf-8") as file:
#             lyrics = file.read()
#         return jsonify({"lyrics": lyrics})
#     except FileNotFoundError:
#         return jsonify({"lyrics": "가사를 찾을 수 없습니다."})

# @socketio.on('connect')
# def handle_connect():
#     sid = request.sid  # request로부터 sid 가져오기
#     user_name = chr(65 + len(users))  # A, B, C, ... 순차적으로 부여
#     user_color = random.choice(colors)
#     users[sid] = {'name': user_name, 'color': user_color}
#     print(f"User {user_name} connected with SID: {sid}")

# @socketio.on('disconnect')
# def handle_disconnect():
#     sid = request.sid
#     if sid in users:
#         print(f"User {users[sid]['name']} disconnected")
#         del users[sid]

# @socketio.on('message')
# def handleMessage(msg):
#     sid = request.sid
#     user_info = users.get(sid, {'name': 'Unknown', 'color': '#000000'})
#     print(f"{user_info['name']} ({user_info['color']}): {msg}")
#     formatted_message = f"<span style='color:{user_info['color']}'>{user_info['name']}: {msg}</span>"
#     send(formatted_message, broadcast=True)

# if __name__ == '__main__':
#     socketio.run(app, debug=True)
